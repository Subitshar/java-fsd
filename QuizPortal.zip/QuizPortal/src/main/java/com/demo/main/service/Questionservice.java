package com.demo.main.service;

import java.util.List;

import com.demo.main.entity.Question;

public interface Questionservice {
	
	public Question addQuestion(Question ques);
	public List<Question> getAllQuestions();
	public Question getQuestionsById(int id);
	public  Question updateQues(Question ques, int id);
	public boolean deleteQues(int id);

}
