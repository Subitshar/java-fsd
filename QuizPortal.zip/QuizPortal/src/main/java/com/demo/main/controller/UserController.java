package com.demo.main.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.demo.main.entity.Quiz;
import com.demo.main.entity.Result;
import com.demo.main.service.QuizServiceImpl;

@Controller
public class UserController {
	
	@Autowired
	Result result;
	@Autowired
	QuizServiceImpl Service;
	
	Boolean submitted = false;
	
	@ModelAttribute("result")
	public Result getResult() {
		return result;
	}
	
	@GetMapping("/login")
	public String home() {
		return "index.html";
	}
	
	@PostMapping("/quiz")
	public String quiz(@RequestParam String username,@RequestParam String email, Model m, RedirectAttributes ra) {
		if(username.equals("")) {
			ra.addFlashAttribute("warning", "You must enter your name");
			return "redirect:/";
		}
		
		submitted = false;
		result.setUsername(username);
		result.setEmail(email);
		
		Quiz quiz_question = Service.getQuestions();
		m.addAttribute("quiz_question", quiz_question);
		
		return "quiz.html";
	}
	
	@PostMapping("/submit")
	public String submit(@ModelAttribute Quiz quiz_question, Model m) {
		if(!submitted) {
			result.setTotalCorrect(Service.getResult(quiz_question));
			Service.saveScore(result);
			submitted = true;
		}
		
		return "result.html";
	}
	
	@GetMapping("/score")
	public String score(Model m) {
		List<Result> scoreList = Service.getTopScore();
		m.addAttribute("scoreList", scoreList);
		return "scoreboard.html";
	}

}