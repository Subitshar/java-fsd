package com.demo.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.main.entity.Question;
import com.demo.main.entity.Result;
import com.demo.main.service.QuestionServiceImpl;
import com.demo.main.service.QuizServiceImpl;



@RestController
@RequestMapping("/api/admin")
public class AdminController {
	
	@Autowired
	private QuestionServiceImpl service;
	
	@Autowired
	private QuizServiceImpl quizservice;
	
	@PostMapping("/addQuestions")
	public ResponseEntity<Question> addUser(@RequestBody Question question){
		Question user_question= service.addQuestion(question);
		if(user_question!=null)  
			return new ResponseEntity<Question>(user_question,HttpStatus.CREATED);
		else
			return new ResponseEntity<Question>(user_question, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	
	@GetMapping("/getquestions")
	public  List<Question> getAllQues(){
		return service.getAllQuestions();
	}
	
	
	
	
	@GetMapping("/{id}")
	public ResponseEntity<Question> getQuesById(@PathVariable int id){
		  Question user_question= service.getQuestionsById(id);
		  
		  if(user_question!=null)
			  return new ResponseEntity<Question>(user_question,HttpStatus.FOUND);
		  else
			  return new  ResponseEntity<Question>(user_question,HttpStatus.NOT_FOUND);
	}
	
	
	@PutMapping("/{id}")
	public ResponseEntity<Object> updateQues(@RequestBody Question question,@PathVariable int id){
		Question data= service.updateQues(question, id);
		
		if(data!=null)
			return new ResponseEntity<Object>(data,HttpStatus.OK);
		else
			return new ResponseEntity<Object>("Question  is Not Available",HttpStatus.NOT_FOUND);
	}
	
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Object> deleteQues(@PathVariable  int id ){
		
		if(service.deleteQues(id))
			return new ResponseEntity<Object>("Question Deleted by id", HttpStatus.OK);
		else
			return new ResponseEntity<Object>("No question avaliable in this id",HttpStatus.NOT_FOUND);
	}
	
	@GetMapping("/usersscore")
	public List<Result> getAllUser(){
		return quizservice.getTopScore();
	}
	
	
	
	

}
