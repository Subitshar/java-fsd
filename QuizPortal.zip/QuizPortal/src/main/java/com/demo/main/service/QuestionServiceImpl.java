package com.demo.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.main.entity.Question;
import com.demo.main.repo.QuestionRepo;


@Service
public class QuestionServiceImpl implements Questionservice {
	
	@Autowired
	private QuestionRepo repo;
	

	public Question addQuestion(Question ques) {
		return repo.save(ques);
	}
	
	
	
	public List<Question> getAllQuestions(){
		return repo.findAll();
	}
	
	
	public Question getQuestionsById(int id) {
		if(repo.findById(id).isPresent()) 
			return repo.findById(id).get();
		else 
			return null;
		
	}
	
	public  Question updateQues(Question ques, int id) {
		
		if(repo.findById(id).isPresent())
		{
			Question old= repo.findById(id).get();
			old.setQuestion(ques.getQuestion());
			old.setOptionA(ques.getOptionA());
			old.setOptionB(ques.getOptionB());
			old.setOptionC(ques.getOptionC());
			old.setOptionD(ques.getOptionD());
			old.setAns(ques.getAns());
			old.setChose(ques.getChose());
			
			
			return repo.save(old);
		}
		else
		{
			return null;
		}
		
	}
	
	
	public boolean deleteQues(int id) {
		
		if(repo.findById(id).isPresent())
		{
			repo.deleteById(id);
			return true;
		}
		else
			return false;
	}

}