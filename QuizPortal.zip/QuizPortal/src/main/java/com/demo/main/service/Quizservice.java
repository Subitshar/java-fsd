package com.demo.main.service;

import java.util.List;

import com.demo.main.entity.Quiz;
import com.demo.main.entity.Result;

public interface Quizservice {
	
	public Quiz getQuestions();
	public int getResult(Quiz qForm);
	public void saveScore(Result result);
	public List<Result> getTopScore();

}
